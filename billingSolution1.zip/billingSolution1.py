# Anshu Anshu

import pymongo

connection = pymongo.MongoClient("mongodb+srv://Anshu:anshu123@billingsolution.kkjaf.mongodb.net/BillingSolution?retryWrites=true&w=majority")
database = connection['BillingSolution']

collection = database['CustomerInformation']
collection2 = database['ProductInfo']


data =  [{"First name": "Ankita", "Middle name": "", "Last name":  "Sharma", "Contact no": "+1 123456789", "Shipping Address": "58 Keefer place, Downtown, Vancouver, V6B0B8"},
         {"First name": "Ashika", "Middle name": "", "Last name": "Jhanwar", "Contact no": "+1 123456780", "Shipping Address": "98 Keefer place, Richmond, Vancouver, V6L0B8"},
         {"First name": "Naman", "Middle name": "Raj", "Last name": "Mehera", "Contact no": "+1 723451780", "Shipping Address": "102 Scarborough, Toronto, M1L8K8"},
         {"First name": "John", "Middle name": "NA", "Last name": "Burnard", "Contact no": "+1 723451380", "Shipping Address": "56 Burrard Street, Vancouver, V6B4R8"},
         {"First name": "Kitty", "Middle name": "NA", "Last name": "Nathan", "Contact no": "+1 723431080", "Shipping Address": "747 kings street Montreal, C9I2G4"},
         {"First name": "Priya", "Middle name": "NA", "Last name":  "Bedi", "Contact no": "+1 4373334450", "Shipping Address": "10 Red River Crescent, Scarborough, Ontario - M1B1Z6"},
         {"First name": "Jagjeet", "Middle name": "NA", "Last name": "Singh", "Contact no": "+1 7468125347", "Shipping Address": "41, Brimley Road, Ontario - M1B1R4"},
         {"First name": "Hira", "Middle name": "K", "Last name": "Sahni", "Contact no": "+1 437257856", "Shipping Address": "23, Vellore Woods, Vaughan, Ontario - T2RG4S"},
         {"First name": "Charles", "Middle name": "D", "Last name": "Souza", "Contact no": "+1 437125478", "Shipping Address": "12, Warden Avenue, Ontario - V2ST4Z"},
         {"First name": "Jackson", "Middle name": "NA", "Last name": "Sebastian", "Contact no": "+1 647856213", "Shipping Address": "10, Rouge river Drive, Scarbourogh , Ontaio - M2RG4S"}]

data2 = [{"Product Id": 1234, "Product type": "Electrical Appliance", "Product Name": "Samsung Washing Machine", "Description": "This product is sold by xyz seller"},
         {"Product Id": 1235, "Product type": "Clothing", "Product Name": "Nike pro legging", "Description": "This product is sold by abc seller"},
         {"Product Id": 1232, "Product type": "Household", "Product Name": "8-Piece Non-Stick Kitchen Cookware Set, Pots and Pans", "Description": "Return available within 30 days to delivery"},
         {"Product Id": 1231, "Product type": "Cosmetics", "Product Name": "Moroccanoil Extra Volume Shampoo", "Description": "Return available within 30 days to delivery"},
         {"Product Id": 1233, "Product type": "Phone Accesories", "Product Name": "TORRAS iPhone Xs Case", "Description": "Return available within 30 days to delivery"},
         {"Product Id": 2534, "Product type": "Clothing", "Product Name": "H & M women roung neck tee", "Description": "For women of all age groups."},
         {"Product Id": 7412, "Product type": "Electronics", "Product Name": "Apple airpods pro", "Description": "This product is sold by 3rd party seller"},
         {"Product Id": 1204, "Product type": "Cosmetic", "Product Name": "Maybellene Hypercurl Mascara", "Description": "Return/refund available within 30 days of delivery"},
         {"Product Id": 3207, "Product type": "Household Item", "Product Name": "4 pc microwavable bowls set", "Description": "Only exchange no return on this item"},
         {"Product Id": 2536, "Product type": "Jewellery", "Product Name": "Women silver plated bracelet", "Description": "No return, only exchange within 30 days of delivery"}]

def insertData(data):
    collection.insert_many(data)

def insertData2(data):
    collection2.insert_many(data)

#insertData(data)
#insertData2(data2)

def readData():
    customers = collection.find()
    product = collection2.find()

    print("All data from Customer Information")
    for cust in customers:
        print(cust)

    print("All data of product Information")
    for prod in product:
        print(prod)

#readData()

def updateData():
    collection.update_one(
        {"First name": "Ankita"},
        {
            "$set": {
                "Middle name": "S",
                "Contact no": "+1 6752330987",
            }
        })

    collection2.update_one(
        {"Product Id": 1233},
        {
            "$set": {
                "Product type": "Mobile Accessories",
            }
        })

#updateData()


def deleteData():
    query = ({"First name": "Ankita"})
    collection.delete_one(query)

    query1 = ({"Product type": "Clothing"})
    collection2.delete_many(query1)

deleteData()

